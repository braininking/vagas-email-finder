# Vagas Email Finder

Sistema para pesquisar vagas públicas do Themos Vagas e extrair e-mails de candidatura encontrados nas páginas das vagas.

## Arquitetura gratuita

- `frontend/`: React + Vite, publicado no Cloudflare Pages.
- `worker/`: Cloudflare Worker, responsável por consultar o Themos e evitar CORS.
- GitHub: código-fonte e deploy automático.

O plano Free do Cloudflare Workers atualmente permite 100.000 requisições/dia; Pages permite até 500 builds/mês no Free. Consulte a documentação oficial antes de alterar o plano.

## Desenvolvimento

### Frontend

```bash
cd frontend
npm install
npm run dev
```

Defina `VITE_API_URL` apontando para a URL do Worker, por exemplo `https://vagas-email-finder-api.seu-subdominio.workers.dev/api`.

### Worker

```bash
cd worker
npm install
npx wrangler login
npm run dev
npm run deploy
```

## Publicação

1. Criar um repositório GitHub chamado `vagas-email-finder`.
2. Subir este projeto.
3. Criar o Worker no Cloudflare e conectar o repositório ou publicar com Wrangler.
4. Criar o projeto Pages apontando para `frontend/`.
5. No Pages, configurar `VITE_API_URL` com a URL do Worker.

## Observações

O scraper só acessa páginas públicas. Não tenta contornar login, CAPTCHA ou mecanismos de proteção. Como o site de origem pode alterar seu HTML, o parser pode precisar de manutenção futura.
